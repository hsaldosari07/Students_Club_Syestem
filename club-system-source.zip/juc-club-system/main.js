const { app, BrowserWindow, Menu, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { start } = require('./server');

app.setName('نظام إدارة النادي');
app.commandLine.appendSwitch('lang', 'ar');

/* مجلد البيانات: بجانب ملف البرنامج (محمول). لو المكان للقراءة فقط نرجع لمجلد المستخدم. */
function pickDataDir() {
    if (process.env.JUC_DATA) return path.resolve(process.env.JUC_DATA);
    const isDev = /^electron(\.exe)?$/i.test(path.basename(process.execPath));
    const base = isDev ? __dirname : path.dirname(process.execPath);
    const d = path.join(base, 'data');
    try { fs.mkdirSync(d, { recursive: true }); fs.accessSync(d, fs.constants.W_OK); return d; }
    catch (e) { return path.join(app.getPath('userData'), 'data'); }
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null, srv = null, closing = false;

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

async function createWindow() {
    const dataDir = pickDataDir(), token = crypto.randomBytes(16).toString('hex');
    srv = await start({ dataDir, root: __dirname, token });
    win = new BrowserWindow({
        width: 1400, height: 900, minWidth: 980, minHeight: 640, show: false, backgroundColor: '#091313',
        title: 'نظام إدارة النادي الطلابي', autoHideMenuBar: true,
        icon: path.join(__dirname, 'icon.png'),
        webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
    });
    Menu.setApplicationMenu(Menu.buildFromTemplate([
        { label: 'عرض', submenu: [{ role: 'reload', label: 'تحديث' }, { role: 'togglefullscreen', label: 'ملء الشاشة' }, { type: 'separator' }, { role: 'zoomIn', label: 'تكبير' }, { role: 'zoomOut', label: 'تصغير' }, { role: 'resetZoom', label: 'الحجم الطبيعي' }] },
        { label: 'تعديل', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }
    ]));
    const origin = 'http://127.0.0.1:' + srv.port;
    win.webContents.setWindowOpenHandler(({ url }) => {
        if (url.startsWith(origin) || url.startsWith('blob:' + origin) || url === 'about:blank' || url === '') return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, width: 1100, height: 850, icon: path.join(__dirname, 'icon.png') } };
        if (/^https?:/.test(url)) shell.openExternal(url);
        return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(origin)) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
    win.webContents.on('will-prevent-unload', e => e.preventDefault());
    win.once('ready-to-show', () => { win.maximize(); win.show(); });
    /* قبل الإغلاق: نتأكد أن كل شيء انحفظ على القرص */
    win.on('close', async e => {
        if (closing) return; e.preventDefault(); closing = true;
        try { await win.webContents.executeJavaScript('window.__jucFlush ? window.__jucFlush() : true'); } catch (x) {}
        try { srv.close(); } catch (x) {}
        win.destroy();
    });
    await win.loadURL(origin + '/?t=' + token);
}
app.whenReady().then(createWindow).catch(err => { dialog.showErrorBox('تعذّر تشغيل البرنامج', String(err && err.stack || err)); app.quit(); });
app.on('window-all-closed', () => app.quit());
