/*
 * خادم محلي داخلي لبرنامج إدارة النادي — يعمل داخل نافذة البرنامج فقط (127.0.0.1)
 * يحفظ كل البيانات في مجلد data بجانب البرنامج، فيمكن نقله على فلاش/درايف.
 */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.svg': 'image/svg+xml', '.png': 'image/png' };
const KEEP_BACKUPS = 10, MAX_BODY = 400 * 1024 * 1024;

function start({ dataDir, root, token }) {
    const STATE = path.join(dataDir, 'state'), BACKUPS = path.join(dataDir, 'backups');
    fs.mkdirSync(STATE, { recursive: true }); fs.mkdirSync(BACKUPS, { recursive: true });
    const keyOk = k => /^[A-Za-z0-9_.\-]{1,120}$/.test(k), fileOf = k => path.join(STATE, k + '.json');
    const readState = () => { const o = {}; for (const f of fs.readdirSync(STATE)) { if (f.endsWith('.json')) try { o[f.slice(0, -5)] = fs.readFileSync(path.join(STATE, f), 'utf8'); } catch (e) {} } return o; };
    let lastSig = '';
    const sig = () => fs.readdirSync(STATE).sort().map(f => { const s = fs.statSync(path.join(STATE, f)); return f + ':' + s.size + ':' + Math.floor(s.mtimeMs); }).join('|');
    function snapshot(force) {
        const sg = sig(); if (!force && sg === lastSig) return null; if (!fs.readdirSync(STATE).length) return null;
        const d = new Date(), p = n => String(n).padStart(2, '0'), name = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
        const dest = path.join(BACKUPS, name); fs.mkdirSync(dest, { recursive: true });
        for (const f of fs.readdirSync(STATE)) fs.copyFileSync(path.join(STATE, f), path.join(dest, f));
        lastSig = sg; const all = fs.readdirSync(BACKUPS).sort();
        while (all.length > KEEP_BACKUPS) fs.rmSync(path.join(BACKUPS, all.shift()), { recursive: true, force: true });
        return name;
    }
    const send = (res, code, body, type) => { res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); };
    const readBody = req => new Promise((resolve, reject) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > MAX_BODY) { reject(new Error('too large')); req.destroy(); } else ch.push(c); }); req.on('end', () => resolve(Buffer.concat(ch).toString('utf8'))); req.on('error', reject); });
    const authed = req => (req.headers.cookie || '').split(/;\s*/).includes('juc=' + token);

    const server = http.createServer(async (req, res) => {
        try {
            const url = new URL(req.url, 'http://x'), p = url.pathname;
            if (p === '/' && url.searchParams.get('t') === token) { res.writeHead(302, { 'Set-Cookie': 'juc=' + token + '; Path=/; HttpOnly; SameSite=Strict', Location: '/' }); return res.end(); }
            if (!authed(req)) { res.writeHead(403); return res.end('Forbidden'); }
            if (req.method === 'GET' && (p === '/' || p === '/index.html')) return send(res, 200, fs.readFileSync(path.join(root, 'index.html')), MIME['.html']);
            if (req.method === 'GET' && p.startsWith('/vendor/')) {
                const fp = path.normalize(path.join(root, p)); if (!fp.startsWith(path.join(root, 'vendor'))) return send(res, 403, 'no');
                if (!fs.existsSync(fp)) return send(res, 404, 'not found', 'text/plain');
                res.writeHead(200, { 'Content-Type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'max-age=86400' }); return fs.createReadStream(fp).pipe(res);
            }
            if (p === '/api/ping') return send(res, 200, { ok: true });
            if (req.method === 'GET' && p === '/api/state') return send(res, 200, readState());
            if (req.method === 'POST' && p === '/api/backup/now') return send(res, 200, { ok: true, name: snapshot(true) });
            const m = p.match(/^\/api\/state\/([^/]+)$/);
            if (m) {
                const key = decodeURIComponent(m[1]); if (!keyOk(key)) return send(res, 400, { error: 'bad key' });
                if (req.method === 'PUT') { const body = await readBody(req), tmp = fileOf(key) + '.tmp'; fs.writeFileSync(tmp, body); fs.renameSync(tmp, fileOf(key)); return send(res, 200, { ok: true }); }
                if (req.method === 'DELETE') { try { fs.unlinkSync(fileOf(key)); } catch (e) {} return send(res, 200, { ok: true }); }
            }
            send(res, 404, { error: 'not found' });
        } catch (e) { console.error(e); send(res, 500, { error: String(e.message || e) }); }
    });
    return new Promise(resolve => {
        server.listen(0, '127.0.0.1', () => {
            try { snapshot(false); } catch (e) {}
            const timer = setInterval(() => { try { snapshot(false); } catch (e) {} }, 6 * 3600 * 1000);
            resolve({ port: server.address().port, close: () => { clearInterval(timer); try { snapshot(false); } catch (e) {} server.close(); } });
        });
    });
}
module.exports = { start };
