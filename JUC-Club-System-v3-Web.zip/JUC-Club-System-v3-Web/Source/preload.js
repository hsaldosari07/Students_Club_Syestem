const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('jucDesktop', {
    isDesktop: true,
    platform: process.platform,
    /* طباعة أصلية: بدون هوامش + ألوان الخلفية مفعّلة تلقائياً على ويندوز وماك ولينكس */
    print: (opts) => ipcRenderer.invoke('juc:print', opts || {}),
    savePDF: (opts) => ipcRenderer.invoke('juc:savePDF', opts || {}),
    openPath: (p) => ipcRenderer.invoke('juc:openPath', String(p || '')),
    showInFolder: (p) => ipcRenderer.invoke('juc:showInFolder', String(p || '')),
    openDataFolder: () => ipcRenderer.invoke('juc:openData'),
    /* الاستخدام من الجوال عبر الواي فاي */
    lan: () => ipcRenderer.invoke('juc:lan'),
    lanSet: (o) => ipcRenderer.invoke('juc:lanSet', o || {}),
    saveFile: (name, text) => ipcRenderer.invoke('juc:saveFile', { name, text })
});
