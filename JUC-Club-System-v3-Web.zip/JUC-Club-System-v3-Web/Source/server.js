/*
 * خادم محلي داخلي لبرنامج إدارة النادي — يعمل داخل نافذة البرنامج (127.0.0.1)
 * يحفظ كل البيانات في مجلد data بجانب البرنامج، فيمكن نقله على فلاش/درايف.
 * اختياري (3.5): الاستخدام من الجوال والآيباد عبر شبكة الواي فاي نفسها، برابط سري خاص (lanStart).
 */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json' };
const KEEP_BACKUPS = 30, MAX_BODY = 400 * 1024 * 1024;

function start({ dataDir, root, token }) {
    const STATE = path.join(dataDir, 'state'), BACKUPS = path.join(dataDir, 'backups');
    fs.mkdirSync(STATE, { recursive: true }); fs.mkdirSync(BACKUPS, { recursive: true });
    const keyOk = k => /^[A-Za-z0-9_.\-]{1,120}$/.test(k), fileOf = k => path.join(STATE, k + '.json');
    const readState = () => { const o = {}; for (const f of fs.readdirSync(STATE)) { if (f.endsWith('.json')) try { o[f.slice(0, -5)] = fs.readFileSync(path.join(STATE, f), 'utf8'); } catch (e) {} } return o; };
    /* بصمة كل مفتاح: تتغيّر مع كل حفظ — تمنع جهازاً من الكتابة فوق تعديلات جهاز آخر لم يرها */
    const sigOf = k => { try { const s = fs.statSync(fileOf(k)); return s.mtimeMs + ':' + s.size; } catch (e) { return ''; } };
    const readSigs = () => { const o = {}; for (const f of fs.readdirSync(STATE)) if (f.endsWith('.json')) o[f.slice(0, -5)] = sigOf(f.slice(0, -5)); return o; };
    let lastSig = '';
    const sig = () => fs.readdirSync(STATE).sort().map(f => { const s = fs.statSync(path.join(STATE, f)); return f + ':' + s.size + ':' + Math.floor(s.mtimeMs); }).join('|');
    function snapshot(force) {
        const sg = sig(); if (!force && sg === lastSig) return null; if (!fs.readdirSync(STATE).length) return null;
        const d = new Date(), p = n => String(n).padStart(2, '0'), name = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
        let nm = name, k = 1; while (fs.existsSync(path.join(BACKUPS, nm))) nm = name + '-' + (++k); const dest = path.join(BACKUPS, nm); fs.mkdirSync(dest, { recursive: true });
        for (const f of fs.readdirSync(STATE)) fs.copyFileSync(path.join(STATE, f), path.join(dest, f));
        lastSig = sg; const all = fs.readdirSync(BACKUPS).sort();
        while (all.length > KEEP_BACKUPS) fs.rmSync(path.join(BACKUPS, all.shift()), { recursive: true, force: true });
        return nm;
    }
    const send = (res, code, body, type) => { res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); };
    const readBody = req => new Promise((resolve, reject) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > MAX_BODY) { reject(new Error('too large')); req.destroy(); } else ch.push(c); }); req.on('end', () => resolve(Buffer.concat(ch).toString('utf8'))); req.on('error', reject); });
    let lanToken = '';
    const cookies = req => (req.headers.cookie || '').split(/;\s*/);
    const authed = (req, lan) => lan ? (!!lanToken && cookies(req).includes('jucl=' + lanToken)) : cookies(req).includes('juc=' + token);
    const tokEq = (a, b) => !!a && !!b && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

    const handler = lan => async (req, res) => {
        try {
            const url = new URL(req.url, 'http://x'), p = url.pathname, t = url.searchParams.get('t');
            if (!lan && p === '/' && tokEq(t, token)) { res.writeHead(302, { 'Set-Cookie': 'juc=' + token + '; Path=/; HttpOnly; SameSite=Strict', Location: '/' }); return res.end(); }
            /* الجوال: الرابط يبقى كما هو (بالرمز السري) حتى تعمل أيقونة الشاشة الرئيسية كل مرة */
            if (lan && p === '/' && tokEq(t, lanToken)) { res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store', 'Set-Cookie': 'jucl=' + lanToken + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000' }); return res.end(fs.readFileSync(path.join(root, 'index.html'))); }
            if (!authed(req, lan)) { res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(lan ? '<!doctype html><meta name="viewport" content="width=device-width"><body style="font-family:sans-serif;direction:rtl;text-align:center;padding:40px">الرابط غير صالح. افتح البرنامج على الكمبيوتر ← الإعدادات ← «الاستخدام من الجوال والآيباد» وامسح الكود من جديد.</body>' : 'Forbidden'); }
            if (req.method === 'GET' && (p === '/' || p === '/index.html')) return send(res, 200, fs.readFileSync(path.join(root, 'index.html')), MIME['.html']);
            if (req.method === 'GET' && p.startsWith('/vendor/')) {
                const fp = path.normalize(path.join(root, decodeURIComponent(p))); if (!fp.startsWith(path.join(root, 'vendor'))) return send(res, 403, 'no');
                if (!fs.existsSync(fp)) return send(res, 404, 'not found', 'text/plain');
                res.writeHead(200, { 'Content-Type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'max-age=86400' }); return fs.createReadStream(fp).pipe(res);
            }
            if (p === '/api/ping') return send(res, 200, { ok: true, lan: !!lan });
            if (req.method === 'GET' && p === '/api/state') return send(res, 200, readState());
            if (req.method === 'GET' && p === '/api/sigs') return send(res, 200, readSigs());

            const dirSize = d => { let n = 0; try { for (const f of fs.readdirSync(d)) { const st = fs.statSync(path.join(d, f)); n += st.isDirectory() ? dirSize(path.join(d, f)) : st.size; } } catch (e) {} return n; };
            const bakOk = n => /^[0-9_\-]{8,40}(_[a-z]+)?$/.test(n) && fs.existsSync(path.join(BACKUPS, n));
            const bundleOf = dir => { const o = {}; for (const f of fs.readdirSync(dir)) if (f.endsWith('.json')) try { o[f.slice(0, -5)] = fs.readFileSync(path.join(dir, f), 'utf8'); } catch (e) {} return o; };
            const stamp = () => { const d = new Date(), q = n => String(n).padStart(2, '0'); return d.getFullYear() + '-' + q(d.getMonth() + 1) + '-' + q(d.getDate()) + '_' + q(d.getHours()) + q(d.getMinutes()); };
            const sendFile = (res, name, obj) => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': "attachment; filename*=UTF-8''" + encodeURIComponent(name), 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
            if (req.method === 'GET' && p === '/api/export') return sendFile(res, 'juc-backup-' + stamp() + '.json', { app: 'juc-club-system', version: 3, exportedAt: new Date().toISOString(), state: readState() });
            if (req.method === 'GET' && p === '/api/stats') return send(res, 200, { dataBytes: dirSize(STATE), backups: fs.readdirSync(BACKUPS).length, dataDir: lan ? '' : dataDir });
            if (req.method === 'GET' && p === '/api/backups') return send(res, 200, fs.readdirSync(BACKUPS).sort().reverse().map(n => ({ name: n, bytes: dirSize(path.join(BACKUPS, n)), files: fs.readdirSync(path.join(BACKUPS, n)).length })));
            let bm = p.match(/^\/api\/backups\/([^/]+)(?:\/(download|restore))?$/);
            if (bm) {
                const n = decodeURIComponent(bm[1]); if (!bakOk(n)) return send(res, 404, { error: 'not found' });
                if (req.method === 'GET' && bm[2] === 'download') return sendFile(res, 'juc-backup-' + n + '.json', { app: 'juc-club-system', version: 3, exportedAt: new Date().toISOString(), state: bundleOf(path.join(BACKUPS, n)) });
                if (req.method === 'POST' && bm[2] === 'restore') { const safe = snapshot(true); const dir = path.join(BACKUPS, n); for (const f of fs.readdirSync(STATE)) if (f.endsWith('.json')) fs.unlinkSync(path.join(STATE, f)); for (const f of fs.readdirSync(dir)) fs.copyFileSync(path.join(dir, f), path.join(STATE, f)); lastSig = ''; return send(res, 200, { ok: true, safety: safe }); }
                if (req.method === 'DELETE' && !bm[2]) { fs.rmSync(path.join(BACKUPS, n), { recursive: true, force: true }); return send(res, 200, { ok: true }); }
            }
            if (req.method === 'POST' && p === '/api/import') {
                const j = JSON.parse(await readBody(req)); const st = j && (j.state || j); if (!st || typeof st !== 'object') return send(res, 400, { error: 'bad file' });
                const keys = Object.keys(st).filter(k => keyOk(k) && typeof st[k] === 'string'); if (!keys.length) return send(res, 400, { error: 'empty' });
                const safe = snapshot(true);
                for (const f of fs.readdirSync(STATE)) if (f.endsWith('.json')) fs.unlinkSync(path.join(STATE, f));
                for (const k of keys) { const tmp = fileOf(k) + '.tmp'; fs.writeFileSync(tmp, st[k]); fs.renameSync(tmp, fileOf(k)); }
                lastSig = ''; return send(res, 200, { ok: true, keys: keys.length, safety: safe });
            }
            if (req.method === 'POST' && p === '/api/open-data') return send(res, 200, { dir: lan ? '' : dataDir });
            if (req.method === 'POST' && p === '/api/backup/now') return send(res, 200, { ok: true, name: snapshot(true) });
            const m = p.match(/^\/api\/state\/([^/]+)$/);
            if (m) {
                const key = decodeURIComponent(m[1]); if (!keyOk(key)) return send(res, 400, { error: 'bad key' });
                if (req.method === 'PUT') {
                    const body = await readBody(req), base = req.headers['x-juc-base'];
                    /* تعارض: جهاز آخر حفظ هذا الجزء بعد آخر تحميل لهذا الجهاز */
                    if (base !== undefined && base !== sigOf(key)) return send(res, 409, { error: 'conflict', sig: sigOf(key) });
                    const tmp = fileOf(key) + '.tmp'; fs.writeFileSync(tmp, body); fs.renameSync(tmp, fileOf(key)); return send(res, 200, { ok: true, sig: sigOf(key) });
                }
                if (req.method === 'DELETE') { try { fs.unlinkSync(fileOf(key)); } catch (e) {} return send(res, 200, { ok: true }); }
            }
            send(res, 404, { error: 'not found' });
        } catch (e) { console.error(e); send(res, 500, { error: String(e.message || e) }); }
    };
    const server = http.createServer(handler(false));
    let lanServer = null, lanPort = 0;
    /* تشغيل/إيقاف الوصول من الجوال على الشبكة المحلية */
    function lanStart(tok, port) {
        lanToken = String(tok || '');
        if (lanServer) return Promise.resolve({ port: lanPort });
        return new Promise((resolve, reject) => {
            let tries = 0;
            const attempt = pt => {
                const s = http.createServer(handler(true));
                s.once('error', e => { if (e.code === 'EADDRINUSE' && tries++ < 15) return attempt(pt + 1); reject(e); });
                s.listen(pt, '0.0.0.0', () => { lanServer = s; lanPort = s.address().port; resolve({ port: lanPort }); });
            };
            attempt(+port || 8787);
        });
    }
    function lanStop() { if (lanServer) { try { lanServer.close(); lanServer.closeAllConnections && lanServer.closeAllConnections(); } catch (e) {} } lanServer = null; lanPort = 0; lanToken = ''; }
    return new Promise(resolve => {
        server.listen(0, '127.0.0.1', () => {
            try { snapshot(false); } catch (e) {}
            const timer = setInterval(() => { try { snapshot(false); } catch (e) {} }, 6 * 3600 * 1000);
            resolve({ port: server.address().port, lanStart, lanStop, lanStatus: () => ({ running: !!lanServer, port: lanPort }), close: () => { clearInterval(timer); lanStop(); try { snapshot(false); } catch (e) {} server.close(); } });
        });
    });
}
module.exports = { start };
