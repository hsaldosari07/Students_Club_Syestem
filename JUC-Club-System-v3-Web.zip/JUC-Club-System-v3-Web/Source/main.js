const { app, BrowserWindow, Menu, dialog, shell, ipcMain } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto'), os = require('os');
const { start } = require('./server');

/* الاسم الداخلي يبقى كما هو حتى لا يتغير مكان البيانات على ماك عند الترقية من الإصدارات السابقة */
app.setName('نظام إدارة النادي');
app.commandLine.appendSwitch('lang', 'ar');
if (process.platform === 'win32') app.setAppUserModelId('sa.edu.juc.clubsystem');

const IS_MAC = process.platform === 'darwin';
const ICON = path.join(__dirname, 'icon.png');

/* مجلد البيانات: بجانب ملف البرنامج (محمول). لو المكان للقراءة فقط نرجع لمجلد المستخدم. */
function pickDataDir() {
    if (process.env.JUC_DATA) return path.resolve(process.env.JUC_DATA);
    /* النسخة الجاهزة تعمل دائماً من داخل app.asar (ويندوز، ماك، لينكس) */
    const isDev = !/[\\/]app\.asar([\\/]|$)/.test(__dirname);
    /* ماك: البرنامج داخل حزمة .app (للقراءة فقط عمليًا) فنستخدم Application Support؛ AppImage/‏Linux المثبّت: مجلد المستخدم إن لم يكن الكتابة ممكنة */
    if (IS_MAC && !isDev) return path.join(app.getPath('userData'), 'data');
    if (process.env.PORTABLE_EXECUTABLE_DIR) { try { const dd = path.join(process.env.PORTABLE_EXECUTABLE_DIR, 'data'); fs.mkdirSync(dd, { recursive: true }); fs.accessSync(dd, fs.constants.W_OK); return dd; } catch (e) {} }
    const base = isDev ? __dirname : path.dirname(process.execPath);
    const d = path.join(base, 'data');
    try { fs.mkdirSync(d, { recursive: true }); fs.accessSync(d, fs.constants.W_OK); return d; }
    catch (e) { return path.join(app.getPath('userData'), 'data'); }
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null, srv = null, closing = false, DATA_DIR = '';
const savedFiles = new Set();   /* الملفات التي حفظها البرنامج فقط هي التي يُسمح بفتحها */

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function buildMenu() {
    const view = { label: 'عرض', submenu: [{ role: 'reload', label: 'تحديث' }, { role: 'togglefullscreen', label: 'ملء الشاشة' }, { type: 'separator' }, { role: 'zoomIn', label: 'تكبير' }, { role: 'zoomOut', label: 'تصغير' }, { role: 'resetZoom', label: 'الحجم الطبيعي' }] };
    const file = { label: 'ملف', submenu: [{ label: 'فتح مجلد البيانات', click: () => shell.openPath(DATA_DIR) }, { label: 'الاستخدام من الجوال والآيباد…', click: () => { if (win) win.webContents.executeJavaScript('window.v7OpenLan && v7OpenLan()').catch(() => {}); } }, { type: 'separator' }, IS_MAC ? { role: 'close', label: 'إغلاق النافذة' } : { role: 'quit', label: 'إنهاء' }] };
    const edit = { label: 'تعديل', submenu: [{ role: 'undo', label: 'تراجع' }, { role: 'redo', label: 'إعادة' }, { type: 'separator' }, { role: 'cut', label: 'قص' }, { role: 'copy', label: 'نسخ' }, { role: 'paste', label: 'لصق' }, { role: 'selectAll', label: 'تحديد الكل' }] };
    /* على ماك القائمة الأولى هي قائمة البرنامج، ومن دون قائمة "تعديل" لا تعمل اختصارات النسخ واللصق */
    const tpl = IS_MAC ? [{ role: 'appMenu' }, file, edit, view, { role: 'windowMenu', label: 'نافذة' }] : [view, file, edit];
    Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

const childPrefs = () => ({ contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, preload: path.join(__dirname, 'preload.js') });

async function createWindow() {
    const dataDir = DATA_DIR = pickDataDir(), token = crypto.randomBytes(16).toString('hex');
    srv = await start({ dataDir, root: __dirname, token });
    try { await lanApply(); } catch (e) { console.error('lan', e); }
    win = new BrowserWindow({
        width: 1400, height: 900, minWidth: 980, minHeight: 640, show: false, backgroundColor: '#091313',
        title: 'نظام إدارة النادي الطلابي', autoHideMenuBar: true, icon: ICON,
        webPreferences: childPrefs()
    });
    buildMenu();
    const origin = 'http://127.0.0.1:' + srv.port;
    win.webContents.setWindowOpenHandler(({ url }) => {
        /* نوافذ المعاينة والطباعة: كبيرة ومتوسطة على الشاشة */
        if (url.startsWith(origin) || url.startsWith('blob:' + origin) || url === 'about:blank' || url === '') return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, width: 1240, height: 920, minWidth: 700, minHeight: 500, center: true, backgroundColor: '#cfd8d8', icon: ICON, webPreferences: childPrefs() } };
        if (/^https?:/.test(url)) shell.openExternal(url);
        return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(origin)) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
    win.webContents.on('will-prevent-unload', e => e.preventDefault());
    /* لو تعطلت صفحة البرنامج لأي سبب نعيد تحميلها بدل نافذة بيضاء (البيانات محفوظة على القرص) */
    win.webContents.on('render-process-gone', (e, d) => { if (!closing && d.reason !== 'clean-exit') setTimeout(() => { try { win.loadURL(origin + '/?t=' + token); } catch (x) {} }, 400); });
    win.once('ready-to-show', () => { win.maximize(); win.show(); });
    /* قبل الإغلاق: نتأكد أن كل شيء انحفظ على القرص */
    win.on('close', async e => {
        if (closing) return; e.preventDefault(); closing = true;
        try { await win.webContents.executeJavaScript('window.__jucFlush ? window.__jucFlush() : true'); } catch (x) {}
        try { srv.close(); } catch (x) {}
        win.destroy();
    });
    await win.loadURL(origin + '/?t=' + token);
}

/* اسم ملف آمن على كل الأنظمة */
const safeName = (s, ext) => (String(s || 'document').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120) || 'document') + ext;

ipcMain.handle('juc:openData', () => shell.openPath(DATA_DIR));

/* ---------- الاستخدام من الجوال والآيباد عبر الواي فاي (3.5) ---------- */
/* الإعداد يُحفظ في data/lan.json (خارج النسخ الاحتياطية، فلا ينتقل الرمز السري مع ملفات النسخ) */
const lanFile = () => path.join(DATA_DIR, 'lan.json');
const lanCfg = () => { try { return JSON.parse(fs.readFileSync(lanFile(), 'utf8')) || {}; } catch (e) { return {}; } };
const lanSave = c => { try { fs.writeFileSync(lanFile(), JSON.stringify(c)); } catch (e) {} };
function lanIPs() {
    const all = [].concat(...Object.values(os.networkInterfaces())).filter(i => i && (i.family === 'IPv4' || i.family === 4) && !i.internal).map(i => i.address);
    const rank = a => /^192\.168\./.test(a) ? 0 : /^10\./.test(a) ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(a) ? 2 : /^169\.254\./.test(a) ? 9 : 5;
    return [...new Set(all)].sort((a, b) => rank(a) - rank(b));
}
async function lanApply() {
    const c = lanCfg();
    if (!c.enabled) { srv.lanStop(); return; }
    if (!c.token) { c.token = crypto.randomBytes(18).toString('hex'); lanSave(c); }
    const r = await srv.lanStart(c.token, c.port || 8787);
    if (r.port !== c.port) { c.port = r.port; lanSave(c); }
}
function lanStatus() {
    const c = lanCfg(), st = srv ? srv.lanStatus() : { running: false, port: 0 }, port = st.port || c.port || 8787;
    const host = String(os.hostname() || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
    const urls = lanIPs().map(ip => 'http://' + ip + ':' + port + '/?t=' + (c.token || ''));
    return { enabled: !!c.enabled, running: st.running, port, urls, hostUrl: host && c.token ? 'http://' + host + '.local:' + port + '/?t=' + c.token : '', platform: process.platform };
}
ipcMain.handle('juc:lan', () => lanStatus());
ipcMain.handle('juc:lanSet', async (ev, o) => {
    o = o || {}; const c = lanCfg();
    if ('enabled' in o) c.enabled = !!o.enabled;
    if (o.reset) { c.token = crypto.randomBytes(18).toString('hex'); srv.lanStop(); }
    lanSave(c);
    try { await lanApply(); } catch (e) { return Object.assign(lanStatus(), { error: String(e.message || e) }); }
    return lanStatus();
});
ipcMain.handle('juc:print', (ev, o) => new Promise(resolve => {
    try {
        ev.sender.print({ silent: false, printBackground: true, landscape: !!(o && o.landscape), pageSize: 'A4', margins: { marginType: 'none' } },
            (ok, reason) => resolve({ ok, reason: reason || '' }));
    } catch (e) { resolve({ ok: false, reason: String(e.message || e) }); }
}));
ipcMain.handle('juc:savePDF', async (ev, o) => {
    o = o || {};
    const w = BrowserWindow.fromWebContents(ev.sender); if (!w) return { ok: false };
    const r = await dialog.showSaveDialog(w, { title: 'حفظ ملف PDF', defaultPath: path.join(app.getPath('documents'), safeName(o.name, '.pdf')), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    try {
        const buf = await ev.sender.printToPDF({ printBackground: true, preferCSSPageSize: true, landscape: !!o.landscape, pageSize: 'A4', margins: { top: 0, bottom: 0, left: 0, right: 0 } });
        const fp = /\.pdf$/i.test(r.filePath) ? r.filePath : r.filePath + '.pdf';
        fs.writeFileSync(fp, buf); savedFiles.add(fp); return { ok: true, path: fp };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
});
ipcMain.handle('juc:openPath', (ev, p) => savedFiles.has(p) ? shell.openPath(p) : 'denied');
ipcMain.handle('juc:showInFolder', (ev, p) => { if (savedFiles.has(p)) shell.showItemInFolder(p); return true; });
ipcMain.handle('juc:saveFile', async (ev, o) => {
    const w = BrowserWindow.fromWebContents(ev.sender);
    const r = await dialog.showSaveDialog(w, { defaultPath: path.join(app.getPath('documents'), String(o.name || 'file.txt').replace(/[\\/:*?"<>|]+/g, ' ')) });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(r.filePath, String(o.text || ''), 'utf8'); savedFiles.add(r.filePath); return { ok: true, path: r.filePath };
});
app.whenReady().then(createWindow).catch(err => { dialog.showErrorBox('تعذّر تشغيل البرنامج', String(err && err.stack || err)); app.quit(); });
app.on('window-all-closed', () => app.quit());
