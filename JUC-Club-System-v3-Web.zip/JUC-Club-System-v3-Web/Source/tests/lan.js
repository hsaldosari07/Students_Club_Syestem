/* اختبار الاستخدام من الجوال عبر الواي فاي:  electron tests/lan.js --no-sandbox */
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), http = require('http');
const { start } = require('../server');
app.commandLine.appendSwitch('no-sandbox');
const OUT = process.env.E2E_OUT || os.tmpdir();
let pass = 0, fail = 0; const errors = [];
const ok = (c, m) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; console.log('  ✘ FAIL:', m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const req = (port, p, o = {}) => new Promise(res => { const r = http.request({ host: '127.0.0.1', port, path: p, method: o.method || 'GET', headers: o.headers || {} }, x => { let b = ''; x.on('data', d => b += d); x.on('end', () => res({ s: x.statusCode, h: x.headers, b })); }); r.on('error', e => res({ s: 0, e: e.code })); if (o.body) r.write(o.body); r.end(); });
app.whenReady().then(async () => {
    const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'juc-lan-')), TOK = 'desk', LAN = 'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4';
    fs.mkdirSync(path.join(dataDir, 'state'), { recursive: true });
    fs.writeFileSync(path.join(dataDir, 'state', 'juc_system_config_v7.json'), JSON.stringify({ setupDone: true, clubTitle: 'نادي الاختبار' }));
    fs.writeFileSync(path.join(dataDir, 'state', 'juc_club_members_v7.json'), JSON.stringify([{ id: 'm1', nameAr: 'عضو الكمبيوتر', status: 'نشط', socialAccounts: [], certificates: [] }]));
    const srv = await start({ dataDir, root: path.join(__dirname, '..'), token: TOK });
    try {
        console.log('\n[lan-1] الأمان والرابط السري');
        ok((await req(18787, '/api/ping')).s === 0, 'قبل التفعيل: لا يوجد أي منفذ مفتوح على الشبكة');
        const { port } = await srv.lanStart(LAN, 18787);
        ok(port >= 18787, 'التفعيل يفتح منفذ الشبكة ' + port);
        ok((await req(port, '/')).s === 403 && (await req(port, '/?t=wrong')).s === 403, 'بدون الرابط السري أو برابط خاطئ: مرفوض');
        ok((await req(port, '/api/state', { headers: { cookie: 'juc=' + TOK } })).s === 403, 'رمز نافذة الكمبيوتر لا يفتح بيانات الشبكة');
        const home = await req(port, '/?t=' + LAN);
        ok(home.s === 200 && /<html/i.test(home.b) && /jucl=/.test(String(home.h['set-cookie'])) && !home.h.location, 'الرابط السري يفتح البرنامج مباشرة (بدون تحويل — حتى تعمل أيقونة الشاشة الرئيسية)');
        const ck = { cookie: 'jucl=' + LAN };
        const st = await req(port, '/api/stats', { headers: ck });
        ok((await req(port, '/api/state', { headers: ck })).s === 200 && JSON.parse(st.b).dataDir === '' && (await req(port, '/vendor/qrcode.js', { headers: ck })).s === 200, 'بعد الدخول: البيانات والملفات متاحة، ومسار المجلد على الكمبيوتر مخفي');

        console.log('\n[lan-2] حماية التعديل من جهازين');
        const sigs = JSON.parse((await req(port, '/api/sigs', { headers: ck })).b), b0 = sigs.juc_club_members_v7;
        const p1 = await req(port, '/api/state/juc_club_members_v7', { method: 'PUT', headers: Object.assign({ 'x-juc-base': b0 }, ck), body: '[]' });
        const p2 = await req(port, '/api/state/juc_club_members_v7', { method: 'PUT', headers: Object.assign({ 'x-juc-base': b0 }, ck), body: '[1]' });
        ok(p1.s === 200 && p2.s === 409, 'حفظ بنسخة قديمة يُرفض (409) بدل الكتابة فوق تعديل جهاز آخر');
        const p3 = await req(port, '/api/state/juc_club_members_v7', { method: 'PUT', headers: ck, body: fs.readFileSync(path.join(dataDir, 'state', 'juc_club_members_v7.json'), 'utf8') });
        ok(p3.s === 200, 'التوافق مع الطلبات القديمة بدون بصمة');
        fs.writeFileSync(path.join(dataDir, 'state', 'juc_club_members_v7.json'), JSON.stringify([{ id: 'm1', nameAr: 'عضو الكمبيوتر', status: 'نشط', socialAccounts: [], certificates: [] }]));

        console.log('\n[lan-3] الكمبيوتر + الجوال معاً');
        const mk = (url, ua) => { const w = new BrowserWindow({ show: false, width: ua ? 390 : 1300, height: 900, webPreferences: { backgroundThrottling: false, partition: 'p' + Math.random() } }); if (ua) w.webContents.setUserAgent(ua); w.webContents.on('console-message', e => { if (e.level === 'error') errors.push(e.message); }); return w; };
        const ready = async w => { for (let i = 0; i < 60; i++) { await sleep(150); if (await w.webContents.executeJavaScript('typeof goTab==="function"&&!!document.getElementById("dashboardTab")').catch(() => false)) break; } await sleep(500); };
        const desk = mk(`http://127.0.0.1:${srv.port}/?t=${TOK}`), phone = mk(`http://127.0.0.1:${port}/?t=${LAN}`, 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1');
        await desk.loadURL(`http://127.0.0.1:${srv.port}/?t=${TOK}`); await ready(desk);
        await phone.loadURL(`http://127.0.0.1:${port}/?t=${LAN}`); await ready(phone);
        const D = c => desk.webContents.executeJavaScript(c, true), P = c => phone.webContents.executeJavaScript(c, true);
        const ph = await P(`({n:members.length, name:members[0].nameAr, club:systemConfig.clubTitle, url:location.href, srv:!!window.__JUC_SERVER__, apple:!!document.querySelector('link[rel=apple-touch-icon]'), meta:!!document.querySelector('meta[name=apple-mobile-web-app-capable]')})`);
        ok(ph.n === 1 && ph.name === 'عضو الكمبيوتر' && ph.club === 'نادي الاختبار' && /\?t=/.test(ph.url) && ph.srv, 'الجوال يفتح بيانات الكمبيوتر نفسها ' + JSON.stringify(ph));
        ok(ph.apple && ph.meta, 'أيقونة وإعداد الشاشة الرئيسية للآيفون موجودان');
        await P(`(function(){ members.push({id:'p1',nameAr:'عضو من الآيفون',status:'نشط',socialAccounts:[],certificates:[]}); saveData(); })()`); await P('window.__jucFlush()');
        await D(`window.__jucCheckRemote()`); await sleep(1500); await ready(desk);
        const d1 = await D(`members.map(m=>m.nameAr)`);
        ok(d1.includes('عضو من الآيفون'), 'إضافة من الجوال تظهر على الكمبيوتر تلقائياً ' + JSON.stringify(d1));
        /* تعارض: الجوال بنسخة قديمة يعدّل الأعضاء بعد ما عدّلها الكمبيوتر */
        await D(`(function(){ members.push({id:'d2',nameAr:'عضو ثاني من الكمبيوتر',status:'نشط',socialAccounts:[],certificates:[]}); saveData(); })()`); await D('window.__jucFlush()');
        await P(`(function(){ members[0].nameAr='تعديل قديم من الجوال'; saveData(); })()`); await sleep(1200);
        const banner = await P(`[...document.querySelectorAll('div')].some(d=>/عُدّلت من جهاز آخر/.test(d.textContent))`).catch(() => true);
        await sleep(3500); await ready(phone);
        const after = await P(`members.map(m=>m.nameAr)`);
        const disk = JSON.parse(fs.readFileSync(path.join(dataDir, 'state', 'juc_club_members_v7.json'), 'utf8')).map(m => m.nameAr);
        ok(banner && disk.includes('عضو ثاني من الكمبيوتر') && after.includes('عضو ثاني من الكمبيوتر'), 'التعديل من جهازين: لا يُمسح تعديل الكمبيوتر، والجوال يتحدّث لأحدث نسخة ' + JSON.stringify({ disk, after }));
        const und = await P(`(function(){ goTab('membersTab'); renderMembers(); return /undefined/.test(document.getElementById('membersTableBody').innerText); })()`);
        ok(!und, 'قائمة الأعضاء على الجوال بدون كلمة undefined');
        await P(`goTab('rsTab')`); await sleep(400);
        const pr = await P(`(async function(){ goTab('membersTab'); viewMemberDetail(members[0].id); printModalContent('memberPrintArea'); document.getElementById('pGo').click(); await new Promise(r=>setTimeout(r,2500)); const ov=document.getElementById('v6PrintOv'); const r=!!ov && !!ov.querySelector('iframe').contentDocument.querySelector('.ps-bar'); if(ov) ov.remove(); closeModal('memberDetailModal'); return r; })()`);
        ok(pr, 'الطباعة من الجوال تُفتح داخل الصفحة');
        srv.lanStop(); await sleep(300);
        ok((await req(port, '/api/ping')).s === 0, 'إيقاف الخيار يغلق منفذ الشبكة فوراً');

        console.log('\n[lan-4] قسم الإعدادات مع كود QR');
        ipcMain.handle('juc:lan', () => ({ enabled: true, running: true, port: 8787, urls: ['http://192.168.1.20:8787/?t=' + LAN, 'http://10.0.0.5:8787/?t=' + LAN], hostUrl: '', platform: 'win32' }));
        const w3 = new BrowserWindow({ show: false, width: 1300, height: 900, webPreferences: { backgroundThrottling: false, contextIsolation: true, preload: path.join(__dirname, '..', 'preload.js') } });
        await w3.loadURL(`http://127.0.0.1:${srv.port}/?t=${TOK}`); await ready(w3);
        const ui = await w3.webContents.executeJavaScript(`(async function(){ v7OpenLan(); await new Promise(r=>setTimeout(r,900)); const b=document.getElementById('v7Lan'); return {qr:!!b.querySelector('#v7QrBox svg'), urls:b.querySelectorAll('code').length, steps:/إضافة إلى الشاشة الرئيسية/.test(b.innerText), chip:!!document.querySelector('#settingsTab .btn[onclick*="st-mobile"]')}; })()`, true);
        ok(ui.qr && ui.urls === 2 && ui.steps && ui.chip, 'الإعدادات ← «الاستخدام من الجوال والآيباد»: كود QR + الروابط + الخطوات ' + JSON.stringify(ui));
        await sleep(400); w3.webContents.invalidate(); await sleep(1000); fs.writeFileSync(path.join(OUT, 'lan-settings.png'), (await w3.webContents.capturePage()).toPNG());
        phone.webContents.invalidate(); await sleep(800); fs.writeFileSync(path.join(OUT, 'lan-phone.png'), (await phone.webContents.capturePage()).toPNG());
    } catch (e) { fail++; console.log('EXCEPTION', e && e.stack || e); }
    console.log('\nأخطاء الكونسول:', errors.length ? errors.slice(0, 6) : 'لا يوجد');
    console.log(`\nالنتيجة: نجح ${pass} / فشل ${fail}`);
    srv.close(); process.exit(fail ? 1 : 0);
});
