/* اختبار نسخة الويب (PWA) كما على الجوال:  electron tests/web.js <مجلد-الويب> */
const { app, BrowserWindow, session } = require('electron');
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
app.commandLine.appendSwitch('no-sandbox');
const WEB = path.resolve(process.argv.filter(a => !a.startsWith('--')).slice(-1)[0]);
const OUT = process.env.E2E_OUT || os.tmpdir();
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.svg': 'image/svg+xml' };
let pass = 0, fail = 0; const errors = [];
const ok = (c, m) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; console.log('  ✘ FAIL:', m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
/* الموقع على مسار فرعي مثل GitHub Pages: /club/ */
function serve() { return new Promise(r => { const s = http.createServer((q, res) => { let p = decodeURIComponent(new URL(q.url, 'http://x').pathname); if (!p.startsWith('/club/')) { res.writeHead(404); return res.end('nope'); } p = p.slice(6) || 'index.html'; if (p.endsWith('/')) p += 'index.html'; const f = path.join(WEB, p); if (!f.startsWith(WEB) || !fs.existsSync(f)) { res.writeHead(404); return res.end('404'); } res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res); }); s.listen(0, '127.0.0.1', () => r(s)); }); }
app.whenReady().then(async () => {
    let srv = await serve(); const port = srv.address().port, URL0 = `http://localhost:${port}/club/`;
    const ses = session.fromPartition('persist:juc-web-test-' + Date.now());
    const win = new BrowserWindow({ show: false, width: 390, height: 844, webPreferences: { session: ses, backgroundThrottling: false } });
    win.webContents.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1');
    win.webContents.on('console-message', (e) => { const lv = e.level, m = e.message; if (lv === 'error' || lv >= 3) errors.push(m); });
    const ev = c => win.webContents.executeJavaScript(c, true);
    const load = async () => { await win.loadURL(URL0); for (let i = 0; i < 60; i++) { await sleep(150); if (await ev('typeof goTab==="function" && !!document.getElementById("dashboardTab")').catch(() => false)) break; } await sleep(600); };
    try {
        console.log('\n[web-1] التحميل كتطبيق');
        await load();
        const a = await ev(`({web:!!window.__JUC_WEB, server:!!window.__JUC_SERVER__, base:JUC_BASE, manifest:!!document.querySelector('link[rel=manifest]'), apple:!!document.querySelector('link[rel=apple-touch-icon]'), fa:getComputedStyle(document.querySelector('.fa-solid')).fontFamily})`);
        ok(a.web && !a.server && /\/club\/$/.test(a.base) && a.manifest && a.apple, 'يشتغل من موقع في مجلد فرعي ويخزّن على الجهاز ' + JSON.stringify(a));
        ok(/Font Awesome/.test(a.fa), 'الأيقونات والخطوط تتحمل من المسار الصحيح');
        const mf = await ev(`fetch('manifest.webmanifest').then(r=>r.json()).then(m=>({d:m.display,i:m.icons.length,s:m.start_url}))`);
        ok(mf.d === 'standalone' && mf.i === 3, 'ملف التثبيت (manifest): يفتح بشاشة كاملة مثل التطبيق ' + JSON.stringify(mf));

        console.log('\n[web-2] الحفظ على الجهاز');
        await ev(`(function(){ document.querySelectorAll('.modal-overlay.active').forEach(o=>o.classList.remove('active')); try{uiModalClose()}catch(e){} systemConfig.setupDone=true; systemConfig.clubTitle='نادي الجوال'; members.push({id:'w1',nameAr:'عضو من الجوال',nameEn:'',role:'عضو عادي',status:'نشط',major:'إعلام',socialAccounts:[],certificates:[]}); saveData(); return true; })()`);
        await ev(`window.__jucFlush()`); await sleep(300);
        await load();
        const b = await ev(`({n:members.length, name:(members[0]||{}).nameAr, club:systemConfig.clubTitle, badge:(document.getElementById('srvBadge')||{}).textContent})`);
        ok(b.n === 1 && b.name === 'عضو من الجوال' && b.club === 'نادي الجوال', 'البيانات تبقى بعد إغلاق وفتح التطبيق (IndexedDB) ' + JSON.stringify(b));

        console.log('\n[web-3] بدون إنترنت');
        const sw = await ev(`navigator.serviceWorker.ready.then(r=>!!r.active).catch(()=>false)`);
        ok(sw, 'عامل الخدمة (Service Worker) مفعّل');
        await sleep(1500); srv.close(); srv.closeAllConnections && srv.closeAllConnections(); await sleep(300);
        await load();
        const c = await ev(`({ok:typeof goTab==='function', n:members.length, fa:getComputedStyle(document.querySelector('.fa-solid')).fontFamily})`).catch(() => ({ ok: false }));
        ok(c.ok && c.n === 1, 'يفتح ويعرض البيانات بدون إنترنت ' + JSON.stringify(c));
        srv = await new Promise(r => { const s = http.createServer(() => { }); r(s); }); /* placeholder */

        console.log('\n[web-4] الطباعة داخل الصفحة على الجوال');
        const p = await ev(`(async function(){ viewMemberDetail('w1'); printModalContent('memberPrintArea'); document.getElementById('pGo').click(); await new Promise(r=>setTimeout(r,2500));
            const ov=document.getElementById('v6PrintOv'), d=ov&&ov.querySelector('iframe').contentDocument; const r={ov:!!ov, bar:!!(d&&d.querySelector('.ps-bar')), sheets:d?d.querySelectorAll('.ps-sheet').length:0, ready:d?!d.getElementById('psPrint').disabled:false};
            d.getElementById('psClose').click(); r.closed=!document.getElementById('v6PrintOv'); closeModal('memberDetailModal'); return r; })()`);
        ok(p.ov && p.bar && p.sheets >= 1 && p.ready && p.closed, 'معاينة الطباعة تُفتح داخل التطبيق وتُغلق بزر «إغلاق» ' + JSON.stringify(p));

        console.log('\n[web-5] النسخ الاحتياطي والنقل بين الأجهزة');
        const bk = await ev(`(async function(){ goTab('settingsTab'); await new Promise(r=>setTimeout(r,500)); await bkRender(); const box=document.getElementById('v3Backup').innerText;
            const st={}; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); st[k]=localStorage.getItem(k);}
            const desktop={app:'juc-club-system',version:3,state:{juc_club_members_v7:JSON.stringify([{id:'d1',nameAr:'عضو من الكمبيوتر',status:'نشط',socialAccounts:[],certificates:[]}]),juc_system_config_v7:JSON.stringify({setupDone:true,clubTitle:'نادي الكمبيوتر'}),juc_club_events_v7:'[]'}};
            window.confirm=()=>true; window.alert=()=>{}; const dt=new DataTransfer(); dt.items.add(new File([JSON.stringify(desktop)],'b.json',{type:'application/json'})); const inp=document.createElement('input'); inp.type='file'; inp.files=dt.files;
            window.__v6inp=inp; setTimeout(()=>v6Import(window.__v6inp),50); return {ui:/هذا الجهاز/.test(box)&&/استيراد/.test(box), keys:Object.keys(st).length}; })()`);
        ok(bk.ui && bk.keys >= 4, 'قسم النسخ الاحتياطي في الإعدادات يناسب الجوال (تنزيل/مشاركة + استيراد) ' + JSON.stringify(bk));
        await sleep(3500); await load();
        const im = await ev(`({n:members.length, name:(members[0]||{}).nameAr, club:systemConfig.clubTitle})`);
        ok(im.n === 1 && im.name === 'عضو من الكمبيوتر' && im.club === 'نادي الكمبيوتر', 'استيراد نسخة الكمبيوتر على الجوال يستبدل البيانات ' + JSON.stringify(im));

        console.log('\n[web-6] الشكل على الجوال');
        const lay = await ev(`(function(){ goTab('dashboardTab'); const nav=document.querySelector('.nav-tabs'); return {sw:document.documentElement.scrollWidth, w:innerWidth, navRows: Math.round(nav.getBoundingClientRect().height), sticky:getComputedStyle(document.querySelector('.nav-tabs-wrapper')).position}; })()`);
        ok(lay.sw <= lay.w + 1 && lay.navRows < 70 && lay.sticky === 'sticky', 'لا تمرير جانبي، والتبويبات سطر واحد مثبّت أعلى الشاشة ' + JSON.stringify(lay));
        await sleep(500); win.webContents.invalidate(); await sleep(1200); fs.writeFileSync(path.join(OUT, 'web-phone.png'), (await win.webContents.capturePage()).toPNG());
    } catch (e) { fail++; console.log('EXCEPTION', e && e.stack || e); }
    console.log('\nأخطاء الكونسول:', errors.length ? errors.slice(0, 8) : 'لا يوجد');
    console.log(`\nالنتيجة: نجح ${pass} / فشل ${fail}`);
    try { srv.close(); } catch (e) {} process.exit(fail ? 1 : 0);
});
