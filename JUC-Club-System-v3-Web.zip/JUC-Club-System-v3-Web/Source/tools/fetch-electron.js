/* ينزّل حزم Electron الرسمية لماك (لبناء نسخة ماك من ويندوز) ويطبع مسارها */
const { downloadArtifact } = require('@electron/get');
const version = require('electron/package.json').version;
(async () => {
    for (const arch of (process.argv[2] || 'x64,arm64').split(',')) {
        const p = await downloadArtifact({ version, platform: 'darwin', arch, artifactName: 'electron' });
        console.log(arch + '=' + p);
    }
})().catch(e => { console.error(e); process.exit(1); });
