/* يحوّل صورة الشعار إلى أيقونات البرنامج (خارج البرنامج فقط: النافذة، شريط المهام، المثبّت، Dock).
   التشغيل: electron tools/make-icons.js <صورة-الشعار> <مجلد-الإخراج>
   الناتج: icon.png (1024 شفاف) • icon-512.png • mac-1024.png (بلاطة بيضاء بأسلوب ماك) • icon.icns • icon.ico */
const { app, nativeImage, BrowserWindow } = require('electron');
const fs = require('fs'), path = require('path');
app.disableHardwareAcceleration();

const [src, outDir] = process.argv.slice(2).filter(a => !a.startsWith('--'));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function load(p) { const im = nativeImage.createFromPath(p); if (im.isEmpty()) throw new Error('cannot read ' + p); return im; }
const raw = im => ({ w: im.getSize().width, h: im.getSize().height, d: Buffer.from(im.toBitmap()) }); /* BGRA */
const fromRaw = r => nativeImage.createFromBitmap(r.d, { width: r.w, height: r.h });

/* شعار SVG: نرسمه بدقة عالية مع خلفية شفافة ثم نقصّ حدوده */
async function rasterSvg(p) {
    const svg = fs.readFileSync(p, 'utf8'), w = new BrowserWindow({ show: false, webPreferences: { offscreen: true } });
    await w.loadURL('data:text/html,<body></body>');
    const url = await w.webContents.executeJavaScript(`new Promise(r=>{const i=new Image();i.onload=()=>{const k=2048/Math.max(i.width,i.height),c=document.createElement('canvas');c.width=Math.round(i.width*k);c.height=Math.round(i.height*k);const x=c.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(i,0,0,c.width,c.height);r(c.toDataURL('image/png'))};i.src='data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}'})`);
    w.destroy();
    const r0 = raw(nativeImage.createFromDataURL(url)), o = { w: r0.w, h: r0.h, d: Buffer.from(r0.d) };
    for (let i = 0; i < o.d.length; i += 4) { const a = o.d[i + 3] / 255; if (a) { o.d[i] = Math.min(255, Math.round(o.d[i] / a)); o.d[i + 1] = Math.min(255, Math.round(o.d[i + 1] / a)); o.d[i + 2] = Math.min(255, Math.round(o.d[i + 2] / a)); } }
    return o;
}

/* 1) فصل الرمز عن الخلفية الفاتحة: البكسل المشبع بالألوان = الرمز */
function cutEmblem(img) {
    const { w, h, d } = raw(img);
    /* لون الخلفية حول الرمز */
    let br = 0, bg = 0, bb = 0, n = 0;
    for (let y = Math.round(h * .15); y < h * .2; y++) for (let x = Math.round(w * .3); x < w * .7; x++) { const i = (y * w + x) * 4; bb += d[i]; bg += d[i + 1]; br += d[i + 2]; n++; }
    br /= n; bg /= n; bb /= n;
    const alphaOf = i => { const b = d[i], g = d[i + 1], r = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b), s = mx ? (mx - mn) / mx : 0; const dist = Math.hypot(r - br, g - bg, b - bb) / 255; return clamp(Math.max((s - .06) / .2, (dist - .12) / .25), 0, 1); };
    /* حدود الرمز: نبحث فقط في الجزء العلوي (فوق النص) */
    let x0 = w, y0 = h, x1 = 0, y1 = 0;
    const yMax = Math.round(h * .58);
    for (let y = 0; y < yMax; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4, a = alphaOf(i); if (a > .5) { const b = d[i], r = d[i + 2]; if (Math.abs(r - b) > 25 || b > r + 10) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } } }
    if (x1 <= x0) throw new Error('emblem not found');
    const pad = 6; x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(w - 1, x1 + pad); y1 = Math.min(yMax, y1 + pad);
    const cw = x1 - x0 + 1, ch = y1 - y0 + 1, o = Buffer.alloc(cw * ch * 4);
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
        const i = ((y + y0) * w + (x + x0)) * 4, j = (y * cw + x) * 4, a = alphaOf(i);
        if (a <= 0) continue;
        /* إزالة أثر الخلفية من حواف الرمز */
        o[j] = clamp(Math.round((d[i] - (1 - a) * bb) / a), 0, 255); o[j + 1] = clamp(Math.round((d[i + 1] - (1 - a) * bg) / a), 0, 255); o[j + 2] = clamp(Math.round((d[i + 2] - (1 - a) * br) / a), 0, 255); o[j + 3] = Math.round(a * 255);
    }
    console.log('emblem box', { x0, y0, cw, ch, bgColor: [br, bg, bb].map(Math.round) });
    return { w: cw, h: ch, d: o };
}

/* لصق صورة داخل لوحة مربعة */
function compose(size, emblem, scale, tile, solid) {
    const out = { w: size, h: size, d: Buffer.alloc(size * size * 4) };
    if (solid) for (let i = 0; i < out.d.length; i += 4) { out.d[i] = solid[0]; out.d[i + 1] = solid[1]; out.d[i + 2] = solid[2]; out.d[i + 3] = 255; }
    if (tile) { /* بلاطة بيضاء بزوايا دائرية مع ظل خفيف (أسلوب أيقونات ماك) */
        const m = Math.round(size * .1), s = size - 2 * m, r = s * .225;
        const inTile = (x, y, off) => { const cx = clamp(x, m + r, m + s - r), cy = clamp(y - off, m + r, m + s - r); return r - Math.hypot(x - cx, y - off - cy); };
        for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
            const j = (y * size + x) * 4, e = inTile(x + .5, y + .5, 0), sh = inTile(x + .5, y + .5, size * .012);
            if (sh > -size * .02 && e < 1) { const a = clamp((sh + size * .02) / (size * .02), 0, 1) * .22; out.d[j + 3] = Math.round(a * 255); }
            if (e > -1) { const a = clamp(e + .5, 0, 1); const pa = out.d[j + 3] / 255, na = a + pa * (1 - a); out.d[j] = out.d[j + 1] = out.d[j + 2] = Math.round(255 * a / (na || 1)); out.d[j + 3] = Math.round(na * 255); }
        }
    }
    const k = Math.min(size * scale / emblem.w, size * scale / emblem.h), ew = Math.round(emblem.w * k), eh = Math.round(emblem.h * k);
    const scaled = raw(fromRaw(emblem).resize({ width: ew, height: eh, quality: 'best' }));
    const ox = Math.round((size - ew) / 2), oy = Math.round((size - eh) / 2);
    for (let y = 0; y < eh; y++) for (let x = 0; x < ew; x++) {
        const s = (y * ew + x) * 4, t = ((y + oy) * size + (x + ox)) * 4, a = scaled.d[s + 3] / 255; if (!a) continue;
        /* toBitmap يعيد ألواناً مضروبة مسبقاً بالشفافية */
        const pa = out.d[t + 3] / 255, na = a + pa * (1 - a);
        for (let c = 0; c < 3; c++) { const sc = scaled.d[s + c] / a, dc = out.d[t + c]; out.d[t + c] = clamp(Math.round((sc * a + dc * pa * (1 - a)) / (na || 1)), 0, 255); }
        out.d[t + 3] = Math.round(na * 255);
    }
    return out;
}
/* nativeImage يتوقع ألواناً مضروبة بالشفافية */
const toPNG = (r, size) => { const p = Buffer.from(r.d); for (let i = 0; i < p.length; i += 4) { const a = p[i + 3] / 255; p[i] = Math.round(p[i] * a); p[i + 1] = Math.round(p[i + 1] * a); p[i + 2] = Math.round(p[i + 2] * a); } let im = nativeImage.createFromBitmap(p, { width: r.w, height: r.h }); if (size && size !== r.w) im = im.resize({ width: size, height: size, quality: 'best' }); return im.toPNG(); };

function icns(pngs) { /* [type, buffer] */
    const parts = pngs.map(([t, b]) => { const h = Buffer.alloc(8); h.write(t, 0, 'ascii'); h.writeUInt32BE(b.length + 8, 4); return Buffer.concat([h, b]); });
    const body = Buffer.concat(parts), h = Buffer.alloc(8); h.write('icns', 0, 'ascii'); h.writeUInt32BE(body.length + 8, 4); return Buffer.concat([h, body]);
}
function ico(pngs) { /* [size, buffer] — PNG داخل ICO (ويندوز Vista وما بعد) */
    const head = Buffer.alloc(6); head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(pngs.length, 4);
    let off = 6 + 16 * pngs.length; const dir = [];
    for (const [s, b] of pngs) { const e = Buffer.alloc(16); e[0] = s >= 256 ? 0 : s; e[1] = s >= 256 ? 0 : s; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(b.length, 8); e.writeUInt32LE(off, 12); off += b.length; dir.push(e); }
    return Buffer.concat([head, ...dir, ...pngs.map(p => p[1])]);
}

app.whenReady().then(async () => {
    try {
        fs.mkdirSync(outDir, { recursive: true });
        const em = /\.svg$/i.test(src) ? await rasterSvg(src) : cutEmblem(load(src));
        const flat = compose(1024, em, .9, false), mac = compose(1024, em, .58, true);
        fs.writeFileSync(path.join(outDir, 'icon.png'), toPNG(flat));
        fs.writeFileSync(path.join(outDir, 'icon-512.png'), toPNG(flat, 512));
        fs.writeFileSync(path.join(outDir, 'mac-1024.png'), toPNG(mac));
        fs.writeFileSync(path.join(outDir, 'icon.icns'), icns([['ic10', toPNG(mac)], ['ic09', toPNG(mac, 512)], ['ic08', toPNG(mac, 256)], ['ic07', toPNG(mac, 128)], ['ic12', toPNG(mac, 64)], ['ic11', toPNG(mac, 32)]]));
        fs.writeFileSync(path.join(outDir, 'icon.ico'), ico([256, 128, 64, 48, 32, 24, 16].map(s => [s, toPNG(compose(s * 4, em, s <= 32 ? .98 : .92, false), s)])));
        /* الجوال والآيباد (نسخة الويب): أيقونة آبل لازم خلفية ثابتة، وأندرويد يحتاج 192 و maskable بهامش أمان */
        const W = [255, 255, 255];
        fs.writeFileSync(path.join(outDir, 'apple-180.png'), toPNG(compose(720, em, .7, false, W), 180));
        fs.writeFileSync(path.join(outDir, 'icon-192.png'), toPNG(flat, 192));
        fs.writeFileSync(path.join(outDir, 'maskable-512.png'), toPNG(compose(1024, em, .58, false, W), 512));
        console.log('OK', fs.readdirSync(outDir));
    } catch (e) { console.error(e); process.exitCode = 1; }
    app.quit();
});
