/* يرسم لوحة معاينة لتصاميم الشهادات:  electron tools/preview-designs.js <من> <إلى> <ملف.png> [port|land] */
const { app, BrowserWindow } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const { start } = require('../server');
app.commandLine.appendSwitch('no-sandbox');
const [from, to, out, orient] = process.argv.slice(2).filter(a => !a.startsWith('--'));
app.whenReady().then(async () => {
    const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'juc-prev-')), srv = await start({ dataDir, root: path.join(__dirname, '..'), token: 't' });
    const win = new BrowserWindow({ show: false, width: 1500, height: 1000, webPreferences: { contextIsolation: true, preload: path.join(__dirname, '..', 'preload.js') } });
    await win.loadURL(`http://127.0.0.1:${srv.port}/?t=t`); await new Promise(r => setTimeout(r, 1200));
    const png = 'data:image/png;base64,' + fs.readFileSync(path.join(__dirname, '..', 'icon.png')).toString('base64');
    const h = await win.webContents.executeJavaScript(`(async function(){
        try{uiModalClose()}catch(e){} systemConfig.setupDone=true; systemConfig.clubTitle='نادي الإعلام الجامعي'; systemConfig.logoColor=${JSON.stringify(png)};
        certO.orient=${JSON.stringify(orient || 'land')}; await document.fonts.ready;
        const land=certO.orient==='land', W=land?1123:794, H=land?794:1123, k=land?.4:.3;
        const r={name:'سلمان عبدالله القحطاني',event:'ملتقى التطوع',evDate:'2026-09-01',hours:12,role:'منظم'};
        document.body.innerHTML='<div id="g" style="display:flex;flex-wrap:wrap;gap:14px;padding:14px;background:#cfd8d8;direction:rtl;width:1472px"></div>';
        const g=document.getElementById('g');
        for(let i=${+from};i<${+to};i++){ const d=document.createElement('div'); d.style.cssText='text-align:center;font:700 13px Tajawal'; d.innerHTML='<div style="width:'+(W*k)+'px;height:'+(H*k)+'px;overflow:hidden;position:relative;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.2)"><div style="transform:scale('+k+');transform-origin:top right;position:absolute;top:0;right:0">'+buildCert(r,'JUC-C-2026-0001',false,i)+'</div></div>'+designNo(i)+' — '+CERT_DESIGNS[i]; g.appendChild(d); }
        await new Promise(r=>setTimeout(r,600)); return document.getElementById('g').scrollHeight; })()`);
    win.setContentSize(1500, Math.min(h + 20, 6000)); await new Promise(r => setTimeout(r, 700));
    fs.writeFileSync(out, (await win.webContents.capturePage()).toPNG()); console.log('saved', out, h); srv.close(); app.quit();
});
