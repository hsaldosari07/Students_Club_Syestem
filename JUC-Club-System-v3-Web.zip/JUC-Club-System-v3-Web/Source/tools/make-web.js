/*
 * يبني نسخة الويب القابلة للتثبيت (PWA) للجوال والآيباد وأي متصفح:
 *   node tools/make-web.js <مجلد-الإخراج>
 * الناتج مجلد يُرفع كما هو على أي استضافة HTTPS (GitHub Pages / Netlify / Cloudflare Pages)،
 * ثم يُفتح من الجوال ويُضاف إلى الشاشة الرئيسية. البيانات تُحفظ على الجهاز في IndexedDB وتعمل بدون إنترنت.
 */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..'), pkg = require(path.join(ROOT, 'package.json'));
const OUT = path.resolve(process.argv[2] || path.join(ROOT, 'dist', 'web'));

const copyDir = (s, d) => { fs.mkdirSync(d, { recursive: true }); for (const e of fs.readdirSync(s, { withFileTypes: true })) { const a = path.join(s, e.name), b = path.join(d, e.name); if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b); } };
const list = (d, base = d) => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? list(path.join(d, e.name), base) : [path.relative(base, path.join(d, e.name)).replace(/\\/g, '/')]);

fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
copyDir(path.join(ROOT, 'vendor'), path.join(OUT, 'vendor'));
fs.mkdirSync(path.join(OUT, 'icons'), { recursive: true });
for (const f of ['apple-180.png', 'icon-192.png', 'icon-512.png', 'maskable-512.png']) fs.copyFileSync(path.join(ROOT, 'build', 'icons', f), path.join(OUT, 'icons', f));

const HEAD = `<link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icons/apple-180.png"><link rel="icon" type="image/png" href="icons/icon-192.png">`;

/* 1) app.html = البرنامج نفسه + روابط التثبيت */
let appHtml = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
appHtml = appHtml.replace('<meta charset="UTF-8">', '<meta charset="UTF-8">' + HEAD);
fs.writeFileSync(path.join(OUT, 'app.html'), appHtml);

/* 2) index.html = مُحمِّل صغير: يقرأ البيانات من IndexedDB ثم يشغّل البرنامج */
const loader = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="theme-color" content="#091313"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="نظام النادي">
<title>نظام إدارة النادي الطلابي</title>${HEAD}
<style>html,body{margin:0;height:100%;background:#091313;color:#e8f2f2;font-family:system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif}
.s{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px}.s img{width:96px;height:96px;border-radius:22px;background:#fff;padding:10px;box-sizing:border-box}
.s b{font-size:18px}.s small{opacity:.7}.bar{width:140px;height:4px;border-radius:4px;background:#173232;overflow:hidden}.bar i{display:block;height:100%;width:40%;background:#a38855;animation:m 1s infinite ease-in-out}
@keyframes m{0%{transform:translateX(150%)}100%{transform:translateX(-250%)}}</style></head>
<body><div class="s"><img src="icons/icon-192.png" alt=""><b>نظام إدارة النادي الطلابي</b><div class="bar"><i></i></div><small id="msg">جاري التحميل…</small></div>
<script>
(function () {
  var DB = 'juc-club-system', ST = 'state';
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) navigator.serviceWorker.register('sw.js').catch(function () {});
  function open() { return new Promise(function (res, rej) { var r = indexedDB.open(DB, 1); r.onupgradeneeded = function () { r.result.createObjectStore(ST); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }
  function tx(db, mode, fn) { return new Promise(function (res, rej) { var t = db.transaction(ST, mode); fn(t.objectStore(ST)); t.oncomplete = function () { res(); }; t.onerror = function () { rej(t.error); }; t.onabort = function () { rej(t.error); }; }); }
  function all(db) { return new Promise(function (res, rej) { var o = {}, c = db.transaction(ST, 'readonly').objectStore(ST).openCursor(); c.onsuccess = function () { var cur = c.result; if (cur) { o[cur.key] = cur.value; cur.continue(); } else res(o); }; c.onerror = function () { rej(c.error); }; }); }
  function boot(api) {
    if (api) window.__JUC_IDB = api;
    fetch('app.html', { cache: 'no-cache' }).catch(function () { return caches.match('app.html'); }).then(function (r) { return r.text(); }).then(function (html) { document.open(); document.write(html); document.close(); })
      .catch(function (e) { document.getElementById('msg').textContent = 'تعذّر التحميل: ' + e; });
  }
  open().then(function (db) {
    return all(db).then(function (data) {
      boot({ data: data, put: function (k, v) { return tx(db, 'readwrite', function (s) { s.put(v, k); }); }, del: function (k) { return tx(db, 'readwrite', function (s) { s.delete(k); }); } });
    });
  }).catch(function () { boot(null); });
})();
</script></body></html>`;
fs.writeFileSync(path.join(OUT, 'index.html'), loader);

/* 3) manifest */
fs.writeFileSync(path.join(OUT, 'manifest.webmanifest'), JSON.stringify({
    name: 'نظام إدارة النادي الطلابي — JUC Club System', short_name: 'نظام النادي', description: pkg.description,
    id: './', start_url: './', scope: './', display: 'standalone', orientation: 'any', dir: 'rtl', lang: 'ar',
    background_color: '#091313', theme_color: '#091313', categories: ['education', 'productivity'],
    icons: [{ src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' }, { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }]
}, null, 2));

/* 4) service worker: يعمل بدون إنترنت، ويحدّث البرنامج تلقائياً عند توفر نسخة جديدة */
const files = list(OUT).filter(f => f !== 'sw.js');
const hash = crypto.createHash('sha1'); files.forEach(f => hash.update(f + fs.statSync(path.join(OUT, f)).size)); hash.update(appHtml);
const CACHE = 'juc-' + pkg.version + '-' + hash.digest('hex').slice(0, 10);
fs.writeFileSync(path.join(OUT, 'sw.js'), `/* ${pkg.productName || pkg.name} ${pkg.version} */
const CACHE = ${JSON.stringify(CACHE)}, FILES = ${JSON.stringify(['./'].concat(files))};
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('juc-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request; if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
  const shell = r.mode === 'navigate' || /\\/(app|index)\\.html$|\\/$/.test(new URL(r.url).pathname);
  if (shell) { e.respondWith(fetch(r).then(res => { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); return res; }).catch(() => caches.match(r, { ignoreSearch: true }).then(m => m || caches.match('./')))); return; }
  e.respondWith(caches.match(r, { ignoreSearch: true }).then(m => m || fetch(r).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); } return res; })));
});
`);
fs.writeFileSync(path.join(OUT, '.nojekyll'), '');
console.log('WEB OK', OUT, files.length + 2, 'files', CACHE);
