/*
 * يجمع البرنامج في ثلاثة ملفات ZIP منفصلة: ويندوز، ماك، لينكس (كل ملف فيه الكود المصدري أيضاً).
 * يُشغَّل من ويندوز بعد:  electron-builder --win --x64  و  electron-builder --linux dir --x64
 *   node tools/make-release.js <مجلد-dist> <مجلد-الإخراج>
 * نسخة ماك تُبنى من حزم Electron الرسمية (موقّعة توقيع linker فقط، بلا ختم موارد)، فنعدّل Info.plist
 * ونضيف app.asar والأيقونة مع الحفاظ على الروابط الرمزية وصلاحيات التنفيذ داخل الـ ZIP.
 */
const fs = require('fs'), path = require('path'), yazl = require('yazl'), yauzl = require('yauzl');
const { downloadArtifact } = require('@electron/get');
const ROOT = path.join(__dirname, '..'), pkg = require(path.join(ROOT, 'package.json'));
const [distDir, outDir] = process.argv.slice(2);
const NAME = 'JUC-Club-System-v3';
const MAC_APP = 'JUC Club System.app';
let zip, TOP, files = 0;
function begin(top) { zip = new yazl.ZipFile(); TOP = top + '/'; files = 0; }
const finish = out => new Promise((res, rej) => { zip.outputStream.pipe(fs.createWriteStream(out)).on('close', () => { console.log('DONE', path.basename(out), files, 'entries', (fs.statSync(out).size / 1048576).toFixed(1) + ' MB'); res(); }).on('error', rej); zip.end(); });
const add = (buf, name, mode, compress = true) => { zip.addBuffer(buf, TOP + name, { mode: mode || 0o100644, compress, mtime: new Date() }); files++; };
const addFile = (src, name, mode, compress = true) => { zip.addFile(src, TOP + name, { mode: mode || 0o100644, compress }); files++; };
function addDir(src, dest, modeOf) {
    for (const e of fs.readdirSync(src, { withFileTypes: true })) {
        const s = path.join(src, e.name), d = dest + '/' + e.name;
        if (e.isDirectory()) addDir(s, d, modeOf); else addFile(s, d, modeOf ? modeOf(e.name, d) : 0o100644);
    }
}
const lf = s => Buffer.from(s.replace(/\r?\n/g, '\n'), 'utf8');
const crlf = s => Buffer.from('﻿' + s.replace(/\r?\n/g, '\r\n'), 'utf8');

/* ---------- ويندوز ---------- */
function windows() {
    const setup = fs.readdirSync(distDir).find(f => /windows-setup\.exe$/.test(f));
    if (!setup) throw new Error('no setup exe in dist');
    addFile(path.join(distDir, setup), 'JUC-Club-System-Setup.exe', 0o100755, false);
    addDir(path.join(distDir, 'win-unpacked'), 'JUC-Club-System (بدون تثبيت)');
}

/* ---------- لينكس ---------- */
function linux() {
    const base = 'JUC-Club-System';
    const exeNames = new Set([pkg.build.executableName, 'chrome-sandbox', 'chrome_crashpad_handler']);
    addDir(path.join(distDir, 'linux-unpacked'), base, n => exeNames.has(n) || /\.so(\.\d+)*$/.test(n) ? 0o100755 : 0o100644);
    addFile(path.join(ROOT, 'build', 'icon.png'), base + '/icon.png');
    add(lf(`#!/bin/sh
# تشغيل نظام إدارة النادي
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/${pkg.build.executableName}" --no-sandbox "$@"
`), base + '/run.sh', 0o100755);
    add(lf(`#!/bin/sh
# يضيف البرنامج لقائمة التطبيقات وسطح المكتب (بعدها تقدر تثبّته في الشريط/المفضلة)
DIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$DIR/run.sh" "$DIR/${pkg.build.executableName}" 2>/dev/null
APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"
cat > "$APPS/juc-club-system.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=JUC Club System
Name[ar]=نظام إدارة النادي
Comment=Student club management
Comment[ar]=نظام إدارة النادي الطلابي
Exec="$DIR/run.sh" %U
Icon=$DIR/icon.png
Terminal=false
Categories=Office;Education;
StartupWMClass=${pkg.name}
EOF
chmod +x "$APPS/juc-club-system.desktop"
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
if [ -d "$DESK" ]; then cp "$APPS/juc-club-system.desktop" "$DESK/" && chmod +x "$DESK/juc-club-system.desktop"; gio set "$DESK/juc-club-system.desktop" metadata::trusted true 2>/dev/null; fi
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" >/dev/null 2>&1
echo "تم التثبيت: ابحث عن «JUC Club System» في قائمة التطبيقات."
`), base + '/install.sh', 0o100755);
}

/* ---------- ماك ---------- */
const readZip = p => new Promise((res, rej) => yauzl.open(p, { lazyEntries: true }, (e, z) => {
    if (e) return rej(e); const out = [];
    z.on('entry', en => {
        if (/\/$/.test(en.fileName)) { out.push({ name: en.fileName, dir: true, mode: (en.externalFileAttributes >>> 16) || 0o40755 }); return z.readEntry(); }
        z.openReadStream(en, (er, s) => { if (er) return rej(er); const ch = []; s.on('data', c => ch.push(c)); s.on('end', () => { out.push({ name: en.fileName, buf: Buffer.concat(ch), mode: (en.externalFileAttributes >>> 16) || 0o100644 }); z.readEntry(); }); });
    });
    z.on('end', () => res(out)); z.on('error', rej); z.readEntry();
}));
function plistSet(xml, key, val) {
    const re = new RegExp(`(<key>${key}</key>\\s*<string>)[^<]*(</string>)`);
    return re.test(xml) ? xml.replace(re, `$1${val}$2`) : xml.replace(/<\/dict>\s*<\/plist>\s*$/, `\t<key>${key}</key>\n\t<string>${val}</string>\n</dict>\n</plist>\n`);
}
async function mac(arch, folder, asar, icns) {
    const zp = await downloadArtifact({ version: require('electron/package.json').version, platform: 'darwin', arch, artifactName: 'electron' });
    const entries = await readZip(zp), dest = folder + '/' + MAC_APP;
    for (const e of entries) {
        if (!e.name.startsWith('Electron.app/')) continue;   /* تراخيص ونسخة في الجذر */
        const rel = e.name.slice('Electron.app/'.length);
        if (rel === 'Contents/Resources/default_app.asar') continue;
        const name = dest + '/' + rel;
        if (e.dir) { zip.addEmptyDirectory(TOP + name.replace(/\/$/, ''), { mode: e.mode }); continue; }
        let buf = e.buf;
        if (rel === 'Contents/Info.plist') {
            let x = buf.toString('utf8');
            x = plistSet(x, 'CFBundleName', 'JUC Club System'); x = plistSet(x, 'CFBundleDisplayName', 'نظام إدارة النادي');
            x = plistSet(x, 'CFBundleIdentifier', pkg.build.appId); x = plistSet(x, 'CFBundleShortVersionString', pkg.version); x = plistSet(x, 'CFBundleVersion', pkg.version);
            x = plistSet(x, 'LSApplicationCategoryType', 'public.app-category.productivity'); x = plistSet(x, 'NSHumanReadableCopyright', 'Husam Saad AL Dosari');
            buf = Buffer.from(x, 'utf8');
        }
        if (rel === 'Contents/Resources/electron.icns') buf = icns;
        const isLink = (e.mode & 0o170000) === 0o120000;
        zip.addBuffer(buf, TOP + name, { mode: e.mode, compress: !isLink }); files++;
    }
    add(asar, dest + '/Contents/Resources/app.asar', 0o100644);
}
const MAC_INSTALL = `#!/bin/bash
# تثبيت نظام إدارة النادي على ماك: ينسخ النسخة المناسبة لجهازك إلى مجلد التطبيقات ويفتحها
cd "$(dirname "$0")" || exit 1
if [ "$(uname -m)" = "arm64" ]; then SRC="Apple Silicon (M1-M4)/${MAC_APP}"; else SRC="Intel/${MAC_APP}"; fi
TARGET="/Applications"
if [ ! -w "$TARGET" ]; then TARGET="$HOME/Applications"; mkdir -p "$TARGET"; fi
echo "جاري تثبيت نظام إدارة النادي في $TARGET ..."
rm -rf "$TARGET/${MAC_APP}"
cp -R "$SRC" "$TARGET/" || { echo "تعذّر النسخ"; exit 1; }
xattr -cr "$TARGET/${MAC_APP}" 2>/dev/null
open "$TARGET/${MAC_APP}"
echo "تم. البرنامج في مجلد التطبيقات، ولتثبيته في الـ Dock: زر يمين على أيقونته ← خيارات ← إبقاء في Dock."
`;

const HEAD = `JUC-Club-System v3 — نظام إدارة النادي الطلابي (الإصدار ${pkg.version})
====================================================================

المهم: فك الضغط (Extract) على نفس الجهاز الذي ستشغّل عليه البرنامج.
`;
const TAIL = `
■ الكود المصدري
  مجلد Source: كامل الكود (index.html هو البرنامج نفسه). للتطوير: npm install ثم npm start.

■ الجوال والآيباد (الأسهل — بدون أي حسابات)
  1) شغّل البرنامج على الكمبيوتر ← الإعدادات ← «الاستخدام من الجوال والآيباد» ← فعّل الخيار.
  2) امسح كود QR بكاميرا الآيفون/الآيباد (نفس شبكة الواي فاي) ← يفتح في Safari.
  3) زر المشاركة ⬆︎ ← «إضافة إلى الشاشة الرئيسية». البيانات نفسها اللي على الكمبيوتر.
  ⚠ لا تفتح ملفات البرنامج من تطبيق «الملفات» في الآيفون — لن تعمل من هناك.
  للاستخدام بدون كمبيوتر: ملف JUC-Club-System-v3-Web.zip (يحتاج نشره مرة على رابط https — الدليل بداخله).

■ النسخ الاحتياطي ونقل البيانات بين الأنظمة
  من الإعدادات ← النسخ الاحتياطي: تنزيل ملف واحد يحوي كل البيانات، ويمكن استيراده على ويندوز أو ماك أو لينكس.
`;
const README = {
    Windows: HEAD + `
■ ويندوز (10 و 11، 64-bit)
  • للتثبيت كبرنامج عادي (قائمة ابدأ + سطح المكتب):
      JUC-Club-System-Setup.exe
    إن ظهرت رسالة «Windows protected your PC» اضغط More info ← Run anyway.
  • للتشغيل مباشرة بدون تثبيت (محمول، يصلح على فلاش):
      JUC-Club-System (بدون تثبيت)\\JUC-Club-System.exe
    البيانات تُحفظ في مجلد data بجانبه.
  • للتثبيت في شريط المهام: شغّل البرنامج ← زر يمين على أيقونته في الشريط ← Pin to taskbar.
` + TAIL,
    Mac: HEAD + `
■ ماك (Apple Silicon M1–M4 أو Intel)
  1) زر يمين على «Install-Mac.command» ← فتح (Open) ← فتح.
     (يختار تلقائياً النسخة المناسبة لجهازك، ينقلها لمجلد التطبيقات ويفتحها)
  2) للتثبيت في الـ Dock: زر يمين على الأيقونة ← Options ← Keep in Dock.
  * لو فضّلت النسخ يدوياً: انسخ «${MAC_APP}» من مجلد جهازك إلى Applications ثم نفّذ في Terminal:
       xattr -cr "/Applications/${MAC_APP}"
  البيانات تُحفظ في: ~/Library/Application Support/نظام إدارة النادي/data
` + TAIL,
    Web: HEAD.replace('فك الضغط (Extract) على نفس الجهاز الذي ستشغّل عليه البرنامج.', 'هذه نسخة الجوال والآيباد (تطبيق ويب يُثبَّت على الشاشة الرئيسية ويعمل بدون إنترنت).') + `
⚠ مهم: لا يعمل التثبيت إذا فتحت الملفات من تطبيق «الملفات» في الآيفون أو فككت الضغط على الجوال؛ لازم يُفتح من رابط https.
  الأسهل لمعظم الناس: من برنامج الكمبيوتر ← الإعدادات ← «الاستخدام من الجوال والآيباد» وامسح الكود (بدون نشر).
  هذه النسخة لمن يريد البرنامج على الجوال بدون الكمبيوتر نهائياً:

■ الخطوة 1 — نشر المجلد مرة واحدة (مجاناً، رابط آمن https)
  الأسهل: Netlify
    1) افتح https://app.netlify.com/drop من الكمبيوتر وسجّل دخول مجاني.
    2) اسحب مجلد «JUC-Club-System-Web» كاملاً وأفلته في الصفحة.
    3) يعطيك رابطاً مثل https://اسم-عشوائي.netlify.app — تقدر تغيّر الاسم من إعدادات الموقع.
  أو GitHub Pages: ارفع محتوى المجلد إلى مستودع، ثم Settings ← Pages ← Deploy from branch.
  (لا يصلح فتح index.html مباشرة من الملفات: التثبيت والعمل بدون إنترنت يحتاجان رابط https)

■ الخطوة 2 — التثبيت على الجهاز
  • آيفون / آيباد: افتح الرابط في Safari ← زر المشاركة ⬆︎ ← «إضافة إلى الشاشة الرئيسية» ← إضافة.
  • أندرويد: افتح الرابط في Chrome ← القائمة ⋮ ← «تثبيت التطبيق» (أو «إضافة إلى الشاشة الرئيسية»).
  • الكمبيوتر (اختياري): في Chrome أو Edge زر التثبيت في شريط العنوان.
  بعدها يفتح من أيقونته بشاشة كاملة مثل أي تطبيق، ويعمل بدون إنترنت.

■ البيانات
  • تُحفظ على نفس الجهاز داخل التطبيق (كل جهاز له بياناته).
  • لنقلها من الكمبيوتر إلى الجوال أو العكس: الإعدادات ← النسخ الاحتياطي ← «تنزيل / مشاركة نسخة احتياطية كاملة»،
    ثم في الجهاز الآخر «استيراد نسخة».
  • خذ نسخة احتياطية بانتظام، خصوصاً قبل حذف التطبيق أو مسح بيانات المتصفح.

■ الطباعة و PDF على الجوال
  زر «طباعة» يفتح نافذة الطباعة في الجهاز؛ ومنها تختار طابعة (AirPrint) أو «حفظ في الملفات» كـ PDF.

■ التحديث
  عند نشر نسخة جديدة على نفس الرابط، يتحدّث التطبيق تلقائياً عند فتحه مع وجود إنترنت.
` + TAIL,
    Linux: HEAD + `
■ لينكس (64-bit)
  • تشغيل مباشر: افتح مجلد JUC-Club-System وشغّل:
       ./run.sh
  • للإضافة لقائمة التطبيقات وسطح المكتب (ثم تثبيته في الشريط/المفضلة):
       ./install.sh
  البيانات تُحفظ في مجلد data بجانب البرنامج.
` + TAIL
};
function source() {
    const skip = new Set(['node_modules', 'dist', '.git']);
    (function walk(src, dest) {
        for (const e of fs.readdirSync(src, { withFileTypes: true })) {
            if (skip.has(e.name) || e.name === 'data' && src === ROOT) continue;
            const s = path.join(src, e.name), d = dest + '/' + e.name;
            if (e.isDirectory()) walk(s, d); else addFile(s, d);
        }
    })(ROOT, 'Source');
    /* مجلد data فارغ في الكود المصدري */
    add(Buffer.alloc(0), 'Source/data/.gitkeep');
}

(async () => {
    const asar = fs.readFileSync(path.join(distDir, 'linux-unpacked', 'resources', 'app.asar'));
    const icns = fs.readFileSync(path.join(ROOT, 'build', 'icon.icns'));
    fs.mkdirSync(outDir, { recursive: true });
    const out = os => path.join(outDir, `${NAME}-${os}.zip`);
    const readme = os => add(crlf(README[os]), 'اقرأني - طريقة التشغيل.txt');

    begin(`${NAME}-Windows`); readme('Windows'); windows(); source(); await finish(out('Windows'));
    begin(`${NAME}-Mac`); readme('Mac');
    await mac('arm64', 'Apple Silicon (M1-M4)', asar, icns); await mac('x64', 'Intel', asar, icns);
    add(lf(MAC_INSTALL), 'Install-Mac.command', 0o100755); source(); await finish(out('Mac'));
    begin(`${NAME}-Linux`); readme('Linux'); linux(); source(); await finish(out('Linux'));
    const webDir = path.join(distDir, 'web');
    if (fs.existsSync(path.join(webDir, 'sw.js'))) { begin(`${NAME}-Web`); readme('Web'); addDir(webDir, 'JUC-Club-System-Web'); source(); await finish(out('Web')); }
})().catch(e => { console.error(e); process.exit(1); });